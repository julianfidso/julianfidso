# Syntax_Focus: teleoperation_node.py

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Wrench
from std_msgs.msg import Int8
import os
import sys
import time

# "Dummy" videodriver for å kjøre Pygame uten skjerm
os.environ["SDL_VIDEODRIVER"] = "dummy"
import pygame

class TeleoperationNode(Node):
    def __init__(self):
        super().__init__('teleoperation_node')
        
        # --- 1. KONFIGURASJON ---
        self.deadzone_threshold = 0.05
        
        # Eksponenter for følsomhet
        self.exponential_power_surge = 2.0 
        self.exponential_power_sway  = 2.0 
        self.exponential_power_yaw   = 3.0 

        # Fysiske kraft-begrensninger (Newton)
        self.maximum_surge_force = 70.0  
        self.maximum_sway_force  = 30.0  
        self.maximum_yaw_torque  = 2.0  

        # --- 2. ORIGINAL MAPPING ---
        self.button_arm         = 0       # A-Knapp (Manuell)
        self.button_auto        = 2       # X-Knapp (Auto) - NYTT
        self.button_kill_lb     = 4       # Bumper Left (Kill)
        self.button_kill_rb     = 5       # Bumper Right (Kill)
        
        self.axis_surge_forward = 5       # RT (Gass)
        self.axis_surge_reverse = 2       # LT (Brems/Revers)
        self.axis_sway_lateral  = 0       # LS X (Sway)
        self.axis_yaw_rotation  = 3       # RS X (Yaw)

        # --- 3. TILSTAND ---
        self.arm_press_start_time = 0.0
        self.is_arming_now = False
        
        self.auto_press_start_time = 0.0  # NYTT
        self.is_auto_arming_now = False   # NYTT
        
        self.is_armed_locally = False
        self.last_published_command = -1

        # --- 4. ROS SETUP ---
        self.joystick_publisher = self.create_publisher(Wrench, '/wrench_joystick', 10)
        self.system_command_publisher = self.create_publisher(Int8, '/system_command', 10)
        
        self.timer = self.create_timer(0.05, self.timer_callback)

        try:
            pygame.init()
            pygame.joystick.init()
            if pygame.joystick.get_count() > 0:
                self.joystick_device = pygame.joystick.Joystick(0)
                self.joystick_device.init()
                self.get_logger().info(f"Kontroller funnet: {self.joystick_device.get_name()}")
            else:
                self.joystick_device = None
                self.get_logger().error("Ingen kontroller funnet!")
        except pygame.error:
            self.joystick_device = None

    def apply_trigger_curve(self, raw_value, deadzone, expo):
        normalized_raw = (raw_value + 1.0) / 2.0
        if normalized_raw < deadzone:
            return 0.0
        mapped = (normalized_raw - deadzone) / (1.0 - deadzone)
        return mapped ** expo

    def apply_deadzone_and_curve(self, raw_value, deadzone, expo):
        if abs(raw_value) < deadzone:
            return 0.0
        sign = 1.0 if raw_value > 0 else -1.0
        normalized = (abs(raw_value) - deadzone) / (1.0 - deadzone)
        return sign * (normalized ** expo)

    def timer_callback(self):
        if self.joystick_device is None:
            return
            
        pygame.event.pump()

        # --- SIKKERHET 1: PANIC SQUEEZE (LT + RT + LB + RB) ---
        lt_pressed = self.joystick_device.get_axis(self.axis_surge_reverse) > 0.5
        rt_pressed = self.joystick_device.get_axis(self.axis_surge_forward) > 0.5
        lb_pressed = self.joystick_device.get_button(self.button_kill_lb)
        rb_pressed = self.joystick_device.get_button(self.button_kill_rb)

        if lt_pressed and rt_pressed and lb_pressed and rb_pressed:
            if self.last_published_command != 0:
                command_message = Int8(data=0)
                self.system_command_publisher.publish(command_message)
                self.last_published_command = 0
                sys.stdout.write("\r" + " " * 80 + "\r")
                self.get_logger().warn(">>> SYSTEMKOMMANDO: 0 (KILLSWITCH) SENDT <<<")
            self.is_armed_locally = False

        # --- SIKKERHET 2: ARMING DELAY (A-KNAPP 1.5s) ---
        elif self.joystick_device.get_button(self.button_arm):
            if not self.is_arming_now:
                self.arm_press_start_time = time.time()
                self.is_arming_now = True
            else:
                if (time.time() - self.arm_press_start_time) >= 1.5: 
                    if self.last_published_command != 1:
                        command_message = Int8(data=1)
                        self.system_command_publisher.publish(command_message)
                        self.last_published_command = 1
                        sys.stdout.write("\r" + " " * 80 + "\r")
                        self.get_logger().info(">>> SYSTEMKOMMANDO: 1 (MANUELL) SENDT <<<")
                    self.is_armed_locally = True
        
        # --- SIKKERHET 2.5: AUTO MODE DELAY (X-KNAPP 4.0s) ---
        elif self.joystick_device.get_button(self.button_auto):
            if not self.is_auto_arming_now:
                self.auto_press_start_time = time.time()
                self.is_auto_arming_now = True
            else:
                if (time.time() - self.auto_press_start_time) >= 4.0: 
                    if self.last_published_command != 2:
                        command_message = Int8(data=2)
                        self.system_command_publisher.publish(command_message)
                        self.last_published_command = 2
                        sys.stdout.write("\r" + " " * 80 + "\r")
                        self.get_logger().info(">>> SYSTEMKOMMANDO: 2 (AUTO) SENDT <<<")
                    self.is_armed_locally = True # Lokal status settes til True for å tillate telemetri-visning
        
        else:
            self.is_arming_now = False
            self.is_auto_arming_now = False

        # --- KONTROLL-LOGIKK (Identisk med original) ---
        raw_surge_forward = self.joystick_device.get_axis(self.axis_surge_forward)
        raw_surge_reverse = self.joystick_device.get_axis(self.axis_surge_reverse)
        
        surge_force_forward = self.apply_trigger_curve(raw_surge_forward, self.deadzone_threshold, self.exponential_power_surge)
        surge_force_reverse = self.apply_trigger_curve(raw_surge_reverse, self.deadzone_threshold, self.exponential_power_surge)
        
        calculated_surge = (surge_force_forward - surge_force_reverse) * self.maximum_surge_force

        raw_sway = self.joystick_device.get_axis(self.axis_sway_lateral)
        calculated_sway = self.apply_deadzone_and_curve(raw_sway, self.deadzone_threshold, self.exponential_power_sway) * self.maximum_sway_force

        raw_yaw = self.joystick_device.get_axis(self.axis_yaw_rotation)
        calculated_yaw = self.apply_deadzone_and_curve(raw_yaw, self.deadzone_threshold, self.exponential_power_yaw) * self.maximum_yaw_torque

        # --- SIKKERHET 3: ZERO-THROTTLE BLOKKERING ---
        if not self.is_armed_locally:
            calculated_surge = 0.0
            calculated_sway = 0.0
            calculated_yaw = 0.0

        # --- PUBLISERING ---
        wrench_message = Wrench()
        wrench_message.force.x  = float(calculated_surge)
        wrench_message.force.y  = float(calculated_sway) * -1.0 
        wrench_message.torque.z = float(calculated_yaw) * -1.0 
        
        self.joystick_publisher.publish(wrench_message)

        # --- DASHBOARD ---
        if self.last_published_command == 2:
            status_text = "  AUTO   "
        elif self.is_armed_locally:
            status_text = "MANUELL  "
        else:
            status_text = "KILLSWITCH"
            
        output_string = f"\r[{status_text}] SURGE: {calculated_surge:+.1f}N | SWAY: {calculated_sway:+.1f}N | YAW: {calculated_yaw:+.1f}Nm      "
        sys.stdout.write(output_string)
        sys.stdout.flush()

def main(args=None):
    rclpy.init(args=args)
    node = TeleoperationNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        sys.stdout.write("\nAvslutter...\n")
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
