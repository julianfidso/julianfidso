#include <ESP32Servo.h>

// Maskinvare-spesifikke pinner (Arduino Nano ESP32)
const int PIN_MOTOR_CONTROLLER_1 = 3;  
const int PIN_MOTOR_CONTROLLER_2 = 4;
const int PIN_MOTOR_CONTROLLER_3 = 11; 
const int PIN_MOTOR_CONTROLLER_4 = 12;

// Indikatorlys og relé pinner
const int PIN_INDICATOR_RED = 9;    // Modus 0 (Deaktivert / Feil)
const int PIN_INDICATOR_YELLOW = 8; // Modus 1 (Manuell)
const int PIN_INDICATOR_GREEN = 7;  // Modus 2 (Automatisk)
const int PIN_RELAY_POWER = 5;      // Reléstyring for strømkutt

// Motorobjekter
Servo servo_motor_1;
Servo servo_motor_2;
Servo servo_motor_3;
Servo servo_motor_4;

// Tidtakere
unsigned long last_heartbeat_milliseconds = 0;
const unsigned long HEARTBEAT_TIMEOUT_MILLISECONDS = 250;

// Databuffer for seriell kommunikasjon
const int SERIAL_BUFFER_SIZE = 32;
char serial_receive_buffer[SERIAL_BUFFER_SIZE];
int buffer_current_index = 0;
bool is_receiving_data = false;

// Funksjonsprototyper
void parse_and_apply_serial_data(char* data_string);
void set_all_motors_neutral();
void set_system_operational_mode(int current_mode);
void initialize_hardware_components();
void read_serial_data_non_blocking();
void verify_system_watchdog_timer();

void setup() {
  Serial.begin(115200);
  
  // Maskinvare-timer allokering (Kritisk for ESP32Servo)
  ESP32PWM::allocateTimer(0);
  ESP32PWM::allocateTimer(1);
  ESP32PWM::allocateTimer(2);
  ESP32PWM::allocateTimer(3);

  initialize_hardware_components();
}

void loop() {
  read_serial_data_non_blocking();
  verify_system_watchdog_timer();
}

void initialize_hardware_components() {
  pinMode(PIN_INDICATOR_RED, OUTPUT);
  pinMode(PIN_INDICATOR_YELLOW, OUTPUT);
  pinMode(PIN_INDICATOR_GREEN, OUTPUT);
  pinMode(PIN_RELAY_POWER, OUTPUT);
  
  // Eksplisitt definering av minimum og maksimum pulsbredde
  servo_motor_1.attach(PIN_MOTOR_CONTROLLER_1, 1000, 2000);
  servo_motor_2.attach(PIN_MOTOR_CONTROLLER_2, 1000, 2000);
  servo_motor_3.attach(PIN_MOTOR_CONTROLLER_3, 1000, 2000);
  servo_motor_4.attach(PIN_MOTOR_CONTROLLER_4, 1000, 2000);
  
  set_all_motors_neutral();
  set_system_operational_mode(0);
}

void read_serial_data_non_blocking() {
  while (Serial.available() > 0) {
    char input_character = Serial.read();
    
    if (input_character == '<') {
      is_receiving_data = true;
      buffer_current_index = 0;
    } 
    else if (is_receiving_data) {
      if (input_character == '>') {
        is_receiving_data = false;
        serial_receive_buffer[buffer_current_index] = '\0';
        parse_and_apply_serial_data(serial_receive_buffer);
      } 
      else {
        serial_receive_buffer[buffer_current_index] = input_character;
        buffer_current_index++;
        
        if (buffer_current_index >= SERIAL_BUFFER_SIZE) {
          is_receiving_data = false;
        }
      }
    }
  }
}

void parse_and_apply_serial_data(char* data_string) {
  char* string_token = strtok(data_string, ",");
  int parsed_values[5];
  int array_index = 0;
  
  while (string_token != NULL && array_index < 5) {
    parsed_values[array_index] = atoi(string_token);
    string_token = strtok(NULL, ",");
    array_index++;
  }

  // Aksepterer utelukkende datapakker med eksakt 5 variabler
  if (array_index == 5) { 
    servo_motor_1.writeMicroseconds(constrain(parsed_values[0], 1100, 1900));
    servo_motor_2.writeMicroseconds(constrain(parsed_values[1], 1100, 1900));
    servo_motor_3.writeMicroseconds(constrain(parsed_values[2], 1100, 1900));
    servo_motor_4.writeMicroseconds(constrain(parsed_values[3], 1100, 1900));
    
    set_system_operational_mode(parsed_values[4]);
    last_heartbeat_milliseconds = millis();
  }
}

void verify_system_watchdog_timer() {
  if (millis() - last_heartbeat_milliseconds > HEARTBEAT_TIMEOUT_MILLISECONDS) {
    set_all_motors_neutral();
    set_system_operational_mode(0);
  }
}

void set_all_motors_neutral() {
  servo_motor_1.writeMicroseconds(1500);
  servo_motor_2.writeMicroseconds(1500);
  servo_motor_3.writeMicroseconds(1500);
  servo_motor_4.writeMicroseconds(1500);
}

void set_system_operational_mode(int current_mode) {
  digitalWrite(PIN_INDICATOR_RED, current_mode == 0 ? HIGH : LOW);
  digitalWrite(PIN_INDICATOR_YELLOW, current_mode == 1 ? HIGH : LOW);
  digitalWrite(PIN_INDICATOR_GREEN, current_mode == 2 ? HIGH : LOW);
  
  digitalWrite(PIN_RELAY_POWER, current_mode > 0 ? HIGH : LOW); 
}
