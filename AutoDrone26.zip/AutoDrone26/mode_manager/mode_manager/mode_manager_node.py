#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray, Int8, Float32
import serial
import math

class ModeManagerNode(Node):
    def __init__(self):
        super().__init__('mode_manager_node')

        # --- SENSOR KONFIGURASJON ---
        self.SENSOR_MAP = {
            'W': '/sensors/water_leak_raw',
            'T': '/sensors/temperature',
        }
        self.sensor_publishers = {}

        # --- FYSISKE KONSTANTER ---
        self.c_fwd = (3.71 * 9.81) / 160000.0
        self.c_rev = (2.92 * 9.81) / 160000.0

        # --- SYSTEM TILSTAND ---
        self.current_mode = 0 

        # --- SERIELL TILKOBLING ---
        self.serial_port_name = '/dev/ttyACM0' # Juster til korrekt port
        self.baud_rate = 115200
        self.arduino = None
        self.connect_serial()

        # --- SUBSCRIBERS & TIMERS ---
        self.sub_forces = self.create_subscription(Float64MultiArray, '/thruster_forces', self.force_callback, 10)
        self.sub_mode = self.create_subscription(Int8, '/system_mode_status', self.mode_callback, 10)
        self.create_timer(0.01, self.read_serial_data)

        self.get_logger().info("Mode Manager Node: Integrert kontroll og sensor-lesing.")

    def connect_serial(self):
        try:
            self.arduino = serial.Serial(self.serial_port_name, self.baud_rate, timeout=0)
        except serial.SerialException as e:
            self.get_logger().error(f"Klarte ikke koble til Arduino: {e}")

    def mode_callback(self, msg):
        self.current_mode = msg.data

    def read_serial_data(self):
        if not self.arduino or not self.arduino.is_open:
            return
        
        while self.arduino.in_waiting > 0:
            line = self.arduino.readline().decode('utf-8', errors='ignore').strip()
            if ":" not in line: continue
            
            parts = line.split(":")
            sensor_id, sensor_val = parts[0], float(parts[1])

            if sensor_id in self.SENSOR_MAP:
                if sensor_id not in self.sensor_publishers:
                    self.sensor_publishers[sensor_id] = self.create_publisher(Float32, self.SENSOR_MAP[sensor_id], 10)
                
                msg = Float32()
                msg.data = sensor_val
                self.sensor_publishers[sensor_id].publish(msg)

    def calculate_pwm(self, force):
        if force >= 0:
            pwm = 1500 + math.sqrt(force / self.c_fwd)
        else:
            pwm = 1500 - math.sqrt(abs(force) / self.c_rev)
        return max(1100, min(1900, int(pwm)))

    def force_callback(self, msg):
        if not self.arduino or not self.arduino.is_open:
            return

        forces = msg.data
        if len(forces) == 4:
            pwm = [self.calculate_pwm(f) for f in forces]
            serial_msg = f"<{pwm[0]},{pwm[1]},{pwm[2]},{pwm[3]},{self.current_mode}>\n"
            self.arduino.write(serial_msg.encode('utf-8'))

def main(args=None):
    rclpy.init(args=args)
    node = ModeManagerNode()
    try:
        rclpy.spin(node)
    finally:
        if node.arduino and node.arduino.is_open:
            node.arduino.write(b"<1500,1500,1500,1500,0>\n")
            node.arduino.close()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()