from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'vision_primus'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'config'), glob(os.path.join('config', '*.yaml'))),
        (os.path.join('share', package_name, 'launch'), glob(os.path.join('launch', '*launch.[pxy][yma]*'))),
    ],
    install_requires=['setuptools', 'depthai'],
    zip_safe=True,
    maintainer='Dev',
    maintainer_email='dev@todo.todo',
    description='Dual Camera node for ASV',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'dual_camera_node = vision_primus.dual_camera_node:main'
        ],
    },
)