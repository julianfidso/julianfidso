#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from rclpy.node import Node
from std_msgs.msg import Int8
import depthai as dai
import subprocess

class DualCameraNode(Node):
    def __init__(self):
        super().__init__('dual_camera_node')
        
        # 1. Hent parametere fra YAML
        self.declare_parameter('front_camera_mxid', '')
        self.declare_parameter('back_camera_mxid', '')
        self.declare_parameter('udp_host', '127.0.0.1')
        self.declare_parameter('udp_port_front', 5000)
        self.declare_parameter('udp_port_back', 5001)
        self.declare_parameter('stream_fps', 30)
        self.declare_parameter('video_bitrate_kbps', 3000)
        self.declare_parameter('auto_disable_back_camera', True)

        self.front_mxid = self.get_parameter('front_camera_mxid').value
        self.back_mxid = self.get_parameter('back_camera_mxid').value
        self.udp_host = self.get_parameter('udp_host').value
        self.fps = self.get_parameter('stream_fps').value
        self.bitrate = self.get_parameter('video_bitrate_kbps').value * 1000 # Konverter til bps
        self.auto_disable = self.get_parameter('auto_disable_back_camera').value

        # 2. Tilstand og Prosesser
        self.current_mode = 0
        self.front_device = None
        self.back_device = None
        self.front_gst_proc = None
        self.back_gst_proc = None

        # 3. Subscriber for Modus
        self.sub_mode = self.create_subscription(Int8, '/system_mode_status', self.mode_callback, 10)

        # 4. Bygg DepthAI Pipelines
        self.front_pipeline = self.create_h265_pipeline("front_h265")
        self.back_pipeline = self.create_h265_pipeline("back_h265")

        # 5. Start FRONT-kameraet (alltid på)
        self.start_front_camera()

        self.get_logger().info("Dual Camera Node er klar. Venter på Modus for bakkamera...")

    def create_h265_pipeline(self, stream_name):
        """Oppretter en DepthAI pipeline som henter RGB, enkoder til H.265 og sender til Jetson via USB"""
        pipeline = dai.Pipeline()
        
        # RGB Node
        cam_rgb = pipeline.create(dai.node.ColorCamera)
        cam_rgb.setBoardSocket(dai.CameraBoardSocket.CAM_A)
        cam_rgb.setResolution(dai.ColorCameraProperties.SensorResolution.THE_1080_P)
        cam_rgb.setFps(self.fps)
        cam_rgb.setInterleaved(False)

        # Video Encoder Node (Bruker kameraets VPU)
        video_enc = pipeline.create(dai.node.VideoEncoder)
        video_enc.setDefaultProfilePreset(self.fps, dai.VideoEncoderProperties.Profile.H265_MAIN)
        video_enc.setBitrate(self.bitrate)

        # Output Node (USB)
        xout = pipeline.create(dai.node.XLinkOut)
        xout.setStreamName(stream_name)

        # Link sammen
        cam_rgb.video.link(video_enc.input)
        video_enc.bitstream.link(xout.input)
        
        return pipeline

    def start_front_camera(self):
        """Kobler til FRONT-kamera og starter GStreamer prosess"""
        try:
            device_info = dai.DeviceInfo(self.front_mxid)
            self.front_device = dai.Device(self.front_pipeline, device_info)
            q_h265 = self.front_device.getOutputQueue(name="front_h265", maxSize=30, blocking=False)
            
            port = self.get_parameter('udp_port_front').value
            self.front_gst_proc = self.start_gstreamer_process(port)
            self.get_logger().info(f"FRONT-kamera stream startet mot {self.udp_host}:{port}")
            
            # Start en timer som mater GStreamer kontinuerlig
            self.front_timer = self.create_timer(1.0 / self.fps, lambda: self.feed_gstreamer(q_h265, self.front_gst_proc))
            
        except RuntimeError as e:
            self.get_logger().error(f"Klarte ikke starte FRONT-kamera: {e}")

    def start_back_camera(self):
        """Kobler til BAK-kamera og starter GStreamer prosess"""
        if self.back_device is not None:
            return # Allerede i gang

        try:
            device_info = dai.DeviceInfo(self.back_mxid)
            self.back_device = dai.Device(self.back_pipeline, device_info)
            q_h265 = self.back_device.getOutputQueue(name="back_h265", maxSize=30, blocking=False)
            
            port = self.get_parameter('udp_port_back').value
            self.back_gst_proc = self.start_gstreamer_process(port)
            self.get_logger().info(f"BAK-kamera stream startet mot {self.udp_host}:{port}")
            
            self.back_timer = self.create_timer(1.0 / self.fps, lambda: self.feed_gstreamer(q_h265, self.back_gst_proc))
            
        except RuntimeError as e:
            self.get_logger().error(f"Klarte ikke starte BAK-kamera: {e}")

    def stop_back_camera(self):
        """Dreper GStreamer og lukker USB-tilkoblingen til BAK-kameraet for å spare strøm/CPU"""
        if self.back_device is not None:
            self.get_logger().info("Stopper BAK-kamera stream (Autonom Modus)")
            self.back_timer.cancel()
            self.back_gst_proc.terminate()
            self.back_gst_proc = None
            self.back_device.close()
            self.back_device = None

    def start_gstreamer_process(self, port):
        """GStreamer pipeline for lav latens over UDP"""
        gst_cmd = (
            f"gst-launch-1.0 fdsrc ! h265parse ! "
            f"rtph265pay config-interval=1 pt=96 ! "
            f"udpsink host={self.udp_host} port={port} sync=false async=false"
        )
        return subprocess.Popen(gst_cmd, shell=True, stdin=subprocess.PIPE)

    def feed_gstreamer(self, queue, proc):
        """Henter en pakke fra OAK-D og trykker den inn i GStreamer"""
        if proc and queue.has():
            pkt = queue.get()
            try:
                proc.stdin.write(pkt.getData())
            except Exception as e:
                self.get_logger().debug(f"GStreamer feed feil (Mottaker nede?): {e}")

    def mode_callback(self, msg):
        new_mode = msg.data
        
        # Hvis vi går inn i Manuell (1), og har deaktivert bakkamera automatisk
        if new_mode == 1 and self.auto_disable:
            self.start_back_camera()
            
        # Hvis vi går inn i Auto (2), skru av bakkamera
        elif new_mode == 2 and self.auto_disable:
            self.stop_back_camera()
            
        self.current_mode = new_mode

def main(args=None):
    rclpy.init(args=args)
    node = DualCameraNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node.front_gst_proc: node.front_gst_proc.terminate()
        if node.back_gst_proc: node.back_gst_proc.terminate()
        node.destroy_node()
        if rclpy.ok(): rclpy.shutdown()

if __name__ == '__main__':
    main()