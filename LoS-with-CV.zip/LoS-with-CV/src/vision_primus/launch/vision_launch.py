import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    config_file = os.path.join(
        get_package_share_directory('vision_primus'),
        'config',
        'camera_params.yaml'
    )

    return LaunchDescription([
        Node(
            package='vision_primus',
            executable='dual_camera_node',
            name='dual_camera_node',
            output='screen',
            parameters=[config_file]
        )
    ])