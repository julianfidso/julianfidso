#include <Servo.h>

// Maskinvare-spesifikke Pins (Nucleo L4R5ZI)
// *SJEKK DATABLAD*: Pinner må støtte TIMx for Hardware PWM.
// Standard Arduino-nummerering fungerer dårlig. D3, D5, D6, D9 er typisk greit,
// men bruk helst port-referanser (f.eks. PA3, PB5) hvis D-makroene feiler.
const int PIN_M1 = D3; // Surge Styrebord
const int PIN_M2 = D5; // Surge Portside
const int PIN_M3 = D6; // Baug 
const int PIN_M4 = D11; // Ersatttet D9 med D11 - Stern
const int PIN_WATER_SENSOR = A0;

// Motorer
Servo servo_m1;
Servo servo_m2;
Servo servo_m3;
Servo servo_m4;

// Timere (Unngå rollover bug med unsigned long)
unsigned long last_heartbeat_ms = 0;
unsigned long last_sensor_tx_ms = 0;
const unsigned long HEARTBEAT_TIMEOUT_MS = 250; // Økt margin for Python overhead
const unsigned long SENSOR_TX_INTERVAL_MS = 500; // 2 Hz oppdatering er mer egnet for ROV

// Parsing Buffer
const int BUFFER_SIZE = 32;
char serial_buffer[BUFFER_SIZE];
int buffer_index = 0;
bool is_receiving = false;

// Funksjonsprototyper (Løser C++ Scope Error)
void parse_and_apply_pwm(char* data_str);
void set_motors_neutral();
void init_hardware();

void setup() {
  Serial.begin(115200);
  init_hardware();
}

void loop() {
  read_serial_non_blocking();
  check_watchdog();
  transmit_sensor_data();
}

// --- HARDWARE INIT ---
void init_hardware() {
  // STM32duino Servo.h knytter seg til TIM-registere via attach()
  servo_m1.attach(PIN_M1);
  servo_m2.attach(PIN_M2);
  servo_m3.attach(PIN_M3);
  servo_m4.attach(PIN_M4);
  set_motors_neutral();
}

// --- SERIELL LESING (State Machine, Unngår String() objektet) ---
// Optimalisert for minne og unngår heap-fragmentering (Viktig på STM32)
void read_serial_non_blocking() {
  while (Serial.available() > 0) {
    char in_char = Serial.read();

    if (in_char == '<') {
      is_receiving = true;
      buffer_index = 0; // Nullstill buffer
    } 
    else if (is_receiving) {
      if (in_char == '>') {
        is_receiving = false;
        serial_buffer[buffer_index] = '\0'; // Terminer string
        parse_and_apply_pwm(serial_buffer);
      } 
      else {
        serial_buffer[buffer_index] = in_char;
        buffer_index++;
        if (buffer_index >= BUFFER_SIZE) {
          is_receiving = false; // Buffer overflow beskyttelse
        }
      }
    }
  }
}

// --- PARSING OG MOTOR KONTROLL ---
void parse_and_apply_pwm(char* data_str) {
  // strtok() er raskere og tryggere enn String.indexOf()
  char* token = strtok(data_str, ",");
  int pwm_values[4];
  int idx = 0;

  while (token != NULL && idx < 4) {
    pwm_values[idx] = atoi(token);
    token = strtok(NULL, ",");
    idx++;
  }

  if (idx == 4) { // Bekreft at 4 verdier ble lest
    // Dobbel sikkerhet: Maskinvarebegrensning
    servo_m1.writeMicroseconds(constrain(pwm_values[0], 1100, 1900));
    servo_m2.writeMicroseconds(constrain(pwm_values[1], 1100, 1900));
    servo_m3.writeMicroseconds(constrain(pwm_values[2], 1100, 1900));
    servo_m4.writeMicroseconds(constrain(pwm_values[3], 1100, 1900));
    
    last_heartbeat_ms = millis(); // Oppdater watchdog kun på gyldig pakke
  }
}

// --- WATCHDOG ---
void check_watchdog() {
  if (millis() - last_heartbeat_ms > HEARTBEAT_TIMEOUT_MS) {
    set_motors_neutral();
  }
}

void set_motors_neutral() {
  servo_m1.writeMicroseconds(1500);
  servo_m2.writeMicroseconds(1500);
  servo_m3.writeMicroseconds(1500);
  servo_m4.writeMicroseconds(1500);
}

// --- SENSOR TRANSMISJON ---
void transmit_sensor_data() {
  if (millis() - last_sensor_tx_ms > SENSOR_TX_INTERVAL_MS) {
    int water_level = analogRead(PIN_WATER_SENSOR);
    
    // Sender i formatet forventet av Python ROS2 noden (Eks: "W:1023\n")
    Serial.print("W:");
    Serial.println(water_level);
    
    last_sensor_tx_ms = millis();
  }
}