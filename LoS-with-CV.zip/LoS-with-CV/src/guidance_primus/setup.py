from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'guidance_primus'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # Sikrer at YAML og Launch kopieres ved bygging
        (os.path.join('share', package_name, 'config'), glob(os.path.join('config', '*.yaml'))),
        (os.path.join('share', package_name, 'launch'), glob(os.path.join('launch', '*launch.[pxy][yma]*'))),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Dev',
    maintainer_email='dev@todo.todo',
    description='APF Guidance Node for ASV',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            # OPPDATERT: Peker nå på den nye APF-noden
            'apf_guidance_node = guidance_primus.apf_guidance_node:main'
        ],
    },
)