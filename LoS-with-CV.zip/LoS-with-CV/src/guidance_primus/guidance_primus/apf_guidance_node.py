#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Point
from nav_msgs.msg import Odometry
from std_msgs.msg import Empty
from sensor_msgs.msg import PointCloud2
import sensor_msgs_py.point_cloud2 as pc2
import math
import numpy as np

class APFGuidanceNode(Node):
    def __init__(self):
        super().__init__('apf_guidance_node')

        # --- 1. PARAMETERE (Hentes fra apf_params.yaml) ---
        self.declare_parameter('timer_freq_hz', 10.0)
        self.declare_parameter('waypoint_radius_m', 1.5)
        self.declare_parameter('yaw_deadband_deg', 3.0)
        self.declare_parameter('max_surge_speed', 1.0)
        self.declare_parameter('max_sway_speed', 0.4)
        self.declare_parameter('max_yaw_rate', 0.5)

        self.declare_parameter('k_attract', 1.0)
        self.declare_parameter('k_repulse', 3.0)
        self.declare_parameter('kp_surge', 0.5)
        self.declare_parameter('kp_sway', 0.8)
        self.declare_parameter('kp_yaw', 1.2)

        self.declare_parameter('roi_max_distance_m', 10.0)
        self.declare_parameter('roi_min_distance_m', 0.5)
        self.declare_parameter('roi_width_m', 4.0)
        self.declare_parameter('min_obstacle_dist', 1.5)

        # --- 2. TILSTANDSVARIABLER ---
        self.mission_active = False
        self.curr_x = 0.0
        self.curr_y = 0.0
        self.curr_yaw = 0.0
        
        self.target_x = 0.0
        self.target_y = 0.0

        # Vektoren som skyver oss bort fra hindringer
        self.repulse_vec = np.array([0.0, 0.0])

        # --- 3. PUBLISHERS & SUBSCRIBERS ---
        self.pub_cmd_vel = self.create_publisher(Twist, '/cmd_vel_nav', 10)
        
        # NY: Melder fra til Mission Manager på land når vi er fremme
        self.pub_reached = self.create_publisher(Empty, '/waypoint_reached', 10)

        self.sub_odom = self.create_subscription(Odometry, '/odometry/filtered_global', self.odom_callback, 10)
        self.sub_wp = self.create_subscription(Point, '/waypoint', self.wp_callback, 10)
        
        # NY: Lytter på dybdedata fra kameraet
        self.sub_pc = self.create_subscription(PointCloud2, '/front_camera/depth/points', self.pc_callback, 1)

        # --- 4. TIMER ---
        freq = self.get_parameter('timer_freq_hz').value
        self.timer = self.create_timer(1.0 / freq, self.control_loop)
        
        self.get_logger().info("APF Guidance Node er klar. Venter på mission...")

    def euler_from_quaternion(self, q):
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny_cosp, cosy_cosp)

    def odom_callback(self, msg):
        self.curr_x = msg.pose.pose.position.x
        self.curr_y = msg.pose.pose.position.y
        self.curr_yaw = self.euler_from_quaternion(msg.pose.pose.orientation)

    def wp_callback(self, msg):
        self.target_x = msg.x
        self.target_y = msg.y
        self.mission_active = True
        self.get_logger().info(f"Nytt mål mottatt: X={self.target_x:.2f}, Y={self.target_y:.2f}.")

    def pc_callback(self, msg):
        """Prosesserer dybdedata for å lage en frastøtende vektor (Repulsive Force)"""
        if not self.mission_active:
            return

        roi_max = self.get_parameter('roi_max_distance_m').value
        roi_min = self.get_parameter('roi_min_distance_m').value
        roi_w = self.get_parameter('roi_width_m').value / 2.0
        k_rep = self.get_parameter('k_repulse').value
        min_dist = self.get_parameter('min_obstacle_dist').value

        repulse_x = 0.0
        repulse_y = 0.0

        # Leser ut punkter fra OAK-D (Antar lokalt referansesystem: X er frem, Y er venstre)
        point_generator = pc2.read_points(msg, field_names=("x", "y", "z"), skip_nans=True)

        for point in point_generator:
            x, y = point[0], point[1]

            # Er punktet inni sikkerhetsboblen?
            if roi_min < x < roi_max and -roi_w < y < roi_w:
                dist = math.hypot(x, y)

                if dist < min_dist:
                    self.get_logger().warn("HINDRING KRITISK NÆRME! Tvinger unnamanøver.")
                    # Skyter inn en massiv negativ vektor for å bråbremse
                    self.repulse_vec = np.array([-50.0, 0.0]) 
                    return

                # Beregner kraft (Eksponentielt sterkere jo nærmere objektet er)
                force_mag = k_rep * (1.0 / dist - 1.0 / roi_max) * (1.0 / (dist**2))

                # Vektoren dytter BORT fra objektet
                repulse_x -= force_mag * (x / dist)
                repulse_y -= force_mag * (y / dist)

        # Begrenser total kraft for å forhindre matematisk "eksplosjon"
        max_force = 10.0
        norm = math.hypot(repulse_x, repulse_y)
        if norm > max_force:
            repulse_x = (repulse_x / norm) * max_force
            repulse_y = (repulse_y / norm) * max_force

        self.repulse_vec = np.array([repulse_x, repulse_y])

    def control_loop(self):
        cmd = Twist()
        if not self.mission_active:
            self.pub_cmd_vel.publish(cmd)
            return

        # 1. ER VI FREMME VED MÅLET?
        dist_to_target = math.hypot(self.target_x - self.curr_x, self.target_y - self.curr_y)
        if dist_to_target <= self.get_parameter('waypoint_radius_m').value:
            self.mission_active = False
            self.pub_reached.publish(Empty()) # Rop tilbake til Mission Manager!
            self.pub_cmd_vel.publish(cmd)
            return

        # 2. TILTREKNING (F_attract)
        dx_global = self.target_x - self.curr_x
        dy_global = self.target_y - self.curr_y
        
        # Båten tenker lokalt, så vi må rotere den globale kart-vektoren til båtens synsvinkel
        attract_x = (dx_global * math.cos(-self.curr_yaw) - dy_global * math.sin(-self.curr_yaw))
        attract_y = (dx_global * math.sin(-self.curr_yaw) + dy_global * math.cos(-self.curr_yaw))

        # Normaliser tiltrekningen (trekker like hardt enten målet er 10m eller 1000m unna)
        k_attract = self.get_parameter('k_attract').value
        norm_att = math.hypot(attract_x, attract_y)
        if norm_att > 0:
            attract_x = (attract_x / norm_att) * k_attract
            attract_y = (attract_y / norm_att) * k_attract

        # 3. KRAFTFUSJON (F_total = F_attract + F_repulse)
        total_x = attract_x + self.repulse_vec[0]
        total_y = attract_y + self.repulse_vec[1]

        # 4. YAW-REGULERING 
        # Matematisk skjønnhet: atan2 av den lokale vektoren GIR oss retningsfeilen direkte!
        target_yaw_error = math.atan2(total_y, total_x)
        
        if abs(target_yaw_error) < math.radians(self.get_parameter('yaw_deadband_deg').value):
            target_yaw_error = 0.0

        # 5. PID PÅDRAG
        raw_surge = self.get_parameter('kp_surge').value * total_x
        raw_sway  = self.get_parameter('kp_sway').value * total_y
        raw_yaw   = self.get_parameter('kp_yaw').value * target_yaw_error

        # 6. CLAMPING (Sikkerhetsgrenser for fart)
        cmd.linear.x = max(min(raw_surge, self.get_parameter('max_surge_speed').value), 0.0) # Båten nekter å rygge
        cmd.linear.y = max(min(raw_sway, self.get_parameter('max_sway_speed').value), -self.get_parameter('max_sway_speed').value)
        cmd.angular.z = max(min(raw_yaw, self.get_parameter('max_yaw_rate').value), -self.get_parameter('max_yaw_rate').value)

        # 7. PUBLISER
        self.pub_cmd_vel.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = APFGuidanceNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok(): rclpy.shutdown()

if __name__ == '__main__':
    main()