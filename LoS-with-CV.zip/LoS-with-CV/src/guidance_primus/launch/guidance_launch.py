import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    
    # OPPDATERT: Henter nå APF-parametere
    config = os.path.join(
        get_package_share_directory('guidance_primus'),
        'config',
        'apf_params.yaml'
    )

    # OPPDATERT: Starter den nye hjernen
    apf_guidance_node = Node(
        package='guidance_primus',
        executable='apf_guidance_node',
        name='apf_guidance_node',
        parameters=[config],
        output='screen'
    )

    return LaunchDescription([
        apf_guidance_node
    ])