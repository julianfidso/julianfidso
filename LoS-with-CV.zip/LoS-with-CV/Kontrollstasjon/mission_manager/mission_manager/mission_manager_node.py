#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
from geographic_msgs.msg import GeoPoint
from robot_localization.srv import FromLL
from std_msgs.msg import Empty

class MissionManagerNode(Node):
    def __init__(self):
        super().__init__('mission_manager_node')
        
        # 1. PARAMETERE
        self.declare_parameter('loop_mission', False)
        self.loop_mission = self.get_parameter('loop_mission').value
        
        self.waypoints = []
        self.current_wp_index = 0
        self.load_waypoints_from_params()

        # 2. PUBLISHERS & SUBSCRIBERS
        self.pub_wp = self.create_publisher(Point, '/waypoint', 10)
        
        # Lytter på båten. Når APF/LOS-noden når punktet, sender den en tom melding hit.
        self.sub_reached = self.create_subscription(Empty, '/waypoint_reached', self.wp_reached_callback, 10)

        # 3. SERVICE CLIENT (GPS til Meter)
        self.cli_from_ll = self.create_client(FromLL, '/fromLL')
        while not self.cli_from_ll.wait_for_service(timeout_sec=2.0):
            self.get_logger().info('Venter på /fromLL tjenesten (er navsat_transform_node startet på båten?)...')

        # 4. START OPPDRAGET
        if len(self.waypoints) > 0:
            self.get_logger().info(f"Lastet inn {len(self.waypoints)} veipunkter. Starter oppdrag...")
            self.send_current_waypoint()
        else:
            self.get_logger().error("Ingen veipunkter funnet i YAML-filen!")

    def load_waypoints_from_params(self):
        """Leser wp1, wp2, wp3 osv. fra YAML-filen dynamisk."""
        idx = 1
        while True:
            param_name = f'waypoints.wp{idx}'
            # Forsøker å lese parameteren. Tillater at den ikke finnes.
            self.declare_parameter(param_name, rclpy.Parameter.Type.DOUBLE_ARRAY)
            wp_data = self.get_parameter(param_name).value
            
            if wp_data is None or len(wp_data) < 2:
                break # Ingen flere punkter funnet
                
            self.waypoints.append({'lat': wp_data[0], 'lon': wp_data[1]})
            idx += 1

    def send_current_waypoint(self):
        """Kaller på robot_localization for å gjøre om GPS til Meter for nåværende mål."""
        if self.current_wp_index >= len(self.waypoints):
            self.get_logger().info("Oppdrag fullført. Ingen flere veipunkter.")
            return

        target = self.waypoints[self.current_wp_index]
        req = FromLL.Request()
        req.ll_point = GeoPoint(latitude=target['lat'], longitude=target['lon'], altitude=0.0)
        
        self.get_logger().info(f"Sender punkt {self.current_wp_index + 1}/{len(self.waypoints)}: Lat={target['lat']}, Lon={target['lon']}")
        
        # Sender forespørsel til båten
        future = self.cli_from_ll.call_async(req)
        future.add_done_callback(self.conversion_response_callback)

    def conversion_response_callback(self, future):
        """Mottar X, Y fra båten og videresender det til autopiloten som det gjeldende målet."""
        try:
            response = future.result()
            target_point = response.map_point
            
            # Publiserer direkte til APF/LOS
            self.pub_wp.publish(target_point)
            self.get_logger().info(f"> Mål sendt til Autopilot: X={target_point.x:.2f}m, Y={target_point.y:.2f}m")
            
        except Exception as e:
            self.get_logger().error(f"Feil under konvertering: {e}")

    def wp_reached_callback(self, msg):
        """Utløses når båten melder at den har nådd målet."""
        self.get_logger().info(f"--- Båten bekrefter ankomst ved punkt {self.current_wp_index + 1} ---")
        self.current_wp_index += 1

        # Sjekk om vi er på slutten av ruten
        if self.current_wp_index >= len(self.waypoints):
            if self.loop_mission:
                self.get_logger().info("Rute ferdig. 'loop_mission' er aktivert. Starter på nytt!")
                self.current_wp_index = 0
            else:
                self.get_logger().info("Rute ferdig. Fartøyet vil nå holde posisjonen.")
                return

        # Send neste
        self.send_current_waypoint()

def main(args=None):
    rclpy.init(args=args)
    node = MissionManagerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()