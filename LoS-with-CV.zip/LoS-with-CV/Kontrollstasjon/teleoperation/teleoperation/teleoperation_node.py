#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Wrench
from std_msgs.msg import Int8
import os
import sys
import time

# "Dummy" videodriver for å kjøre Pygame uten skjerm
os.environ["SDL_VIDEODRIVER"] = "dummy"
import pygame

class TeleoperationNode(Node):
    def __init__(self):
        super().__init__('teleoperation_node')
        
        # --- 1. KONFIGURASJON ---
        self.deadzone_threshold = 0.05
        
        # Individuelle eksponenter for å skreddersy følsomheten pr akse.
        self.exponential_power_surge = 2.0 
        self.exponential_power_sway  = 2.0 
        self.exponential_power_yaw   = 2.0 

        # Fysiske kraft-begrensninger (Newton)
        self.maximum_surge_force = 70.0  
        self.maximum_sway_force  = 30.0  
        self.maximum_yaw_torque  = 10.0  

        # --- 2. MAPPING ---
        self.button_arm         = 0       # A-Knapp (Manuell modus)
        self.button_kill_view   = 6       # View/Back (Del av Killswitch)
        self.button_kill_menu   = 7       # Menu/Start (Del av Killswitch)
        
        self.axis_surge_forward = 5       # RT (Gass fremover)
        self.axis_surge_reverse = 2       # LT (Gass bakover)
        self.axis_yaw_rotation  = 0       # Venstre Stikke X (Rotasjon)
        self.axis_sway_lateral  = 3       # Høyre Stikke X (Sideveis) - Sjekk at dette er 3 (eller 4) på din kontroller!

        # --- 3. TILSTAND ---
        self.is_arming_now = False
        self.arm_press_start_time = 0.0
        self.is_armed_locally = False
        self.last_published_command = -1

        # --- 4. ROS SETUP ---
        self.joystick_publisher = self.create_publisher(Wrench, '/wrench_joystick', 10)
        self.system_command_publisher = self.create_publisher(Int8, '/system_command', 10)
        
        self.control_loop_timer = self.create_timer(0.05, self.timer_callback) # 20 Hz

        # --- 5. PYGAME SETUP ---
        try:
            pygame.init()
            pygame.joystick.init()
            if pygame.joystick.get_count() > 0:
                self.joystick_device = pygame.joystick.Joystick(0)
                self.joystick_device.init()
                self.get_logger().info(f"Kontroller aktiv: {self.joystick_device.get_name()}")
            else:
                self.get_logger().error("Ingen kontroller funnet!")
                self.joystick_device = None
        except pygame.error as error_message:
            self.get_logger().error(f"Pygame init feil: {error_message}")
            self.joystick_device = None

    def apply_deadzone_and_curve(self, raw_value, deadzone, exponent):
        """ Filtrerer mekanisk støy og anvender en eksponentiell kurve for bedre kontroll. """
        if abs(raw_value) < deadzone:
            return 0.0
            
        sign = 1.0 if raw_value > 0 else -1.0
        normalized_value = (abs(raw_value) - deadzone) / (1.0 - deadzone)
        return sign * (normalized_value ** exponent)

    def apply_trigger_curve(self, raw_value, deadzone, exponent):
        """ Spesialtilpasset kurve for Triggers (som starter på -1.0 uansett retning). """
        # Pygame leser gjerne uaktiverte triggere som -1.0, og fullt innklemte som 1.0
        normalized_base = (raw_value + 1.0) / 2.0 
        
        if normalized_base < deadzone:
            return 0.0
            
        normalized_active = (normalized_base - deadzone) / (1.0 - deadzone)
        return normalized_active ** exponent

    def timer_callback(self):
        if self.joystick_device is None:
            return
            
        pygame.event.pump()

        # --- SJEKK 1: KILLSWITCH ---
        # Aktiveres nå ved å trykke Menu og View samtidig.
        if self.joystick_device.get_button(self.button_kill_menu) and self.joystick_device.get_button(self.button_kill_view):
            if self.last_published_command != 0:
                command_message = Int8(data=0)
                self.system_command_publisher.publish(command_message)
                self.last_published_command = 0
                self.get_logger().warn(">>> SYSTEMKOMMANDO: 0 (KILLSWITCH) SENDT <<<")
            self.is_armed_locally = False

        # --- SJEKK 2: MANUELL MODUS ---
        if self.joystick_device.get_button(self.button_arm):
            if not self.is_arming_now:
                self.arm_press_start_time = time.time()
                self.is_arming_now = True
            else:
                if (time.time() - self.arm_press_start_time) >= 1.5: # Lar oss endre tiden for å gå inn i Manuell (1) mode
                    if self.last_published_command != 1:
                        command_message = Int8(data=1)
                        self.system_command_publisher.publish(command_message)
                        self.last_published_command = 1
                        self.get_logger().info(">>> SYSTEMKOMMANDO: 1 (MANUELL) SENDT <<<")
                    self.is_armed_locally = True
        else:
            self.is_arming_now = False

        # --- SJEKK 3: STYRESIGNALER ---
        
        # Surge (Triggere)
        raw_surge_forward = self.joystick_device.get_axis(self.axis_surge_forward)
        raw_surge_reverse = self.joystick_device.get_axis(self.axis_surge_reverse)
        
        surge_force_forward = self.apply_trigger_curve(raw_surge_forward, self.deadzone_threshold, self.exponential_power_surge)
        surge_force_reverse = self.apply_trigger_curve(raw_surge_reverse, self.deadzone_threshold, self.exponential_power_surge)
        
        calculated_surge = (surge_force_forward - surge_force_reverse) * self.maximum_surge_force

        # Sway (Høyre Stikke X)
        raw_sway = self.joystick_device.get_axis(self.axis_sway_lateral)
        calculated_sway = self.apply_deadzone_and_curve(raw_sway, self.deadzone_threshold, self.exponential_power_sway) * self.maximum_sway_force

        # Yaw (Venstre Stikke X)
        raw_yaw = self.joystick_device.get_axis(self.axis_yaw_rotation)
        calculated_yaw = self.apply_deadzone_and_curve(raw_yaw, self.deadzone_threshold, self.exponential_power_yaw) * self.maximum_yaw_torque

        # --- PUBLISERING ---
        wrench_message = Wrench()
        wrench_message.force.x  = float(calculated_surge)
        wrench_message.force.y  = float(calculated_sway)
        wrench_message.torque.z = float(calculated_yaw) * -1.0 # Inverteres for riktig rotasjon
        
        self.joystick_publisher.publish(wrench_message)

        # --- DASHBOARD ---
        status_text = "MANUELL" if self.is_armed_locally else "KILLSWITCH"
        output_string = f"\r[{status_text}] SURGE: {calculated_surge:+.1f}N | SWAY: {calculated_sway:+.1f}N | YAW: {calculated_yaw:+.1f}Nm      "
        sys.stdout.write(output_string)
        sys.stdout.flush()

def main(args=None):
    rclpy.init(args=args)
    teleoperation_node = TeleoperationNode()
    try:
        rclpy.spin(teleoperation_node)
    except KeyboardInterrupt:
        pass
    finally:
        sys.stdout.write("\nAvslutter...\n")
        teleoperation_node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()