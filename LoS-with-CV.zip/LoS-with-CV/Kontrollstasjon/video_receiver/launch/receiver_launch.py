from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='video_receiver',
            executable='video_receiver_node',
            name='dual_video_receiver_node',
            output='screen',
            # Portene er satt til 5000 og 5001 som standard i Python-koden,
            # men de kan overstyres her ved behov senere.
        )
    ])