#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from rclpy.node import Node
import subprocess
import signal
import sys

class DualVideoReceiverNode(Node):
    def __init__(self):
        super().__init__('dual_video_receiver_node')
        
        # 1. PARAMETERE (Må matche det vi satte i camera_params.yaml på båten)
        self.declare_parameter('port_front', 5000)
        self.declare_parameter('port_back', 5001)
        
        self.port_front = self.get_parameter('port_front').value
        self.port_back = self.get_parameter('port_back').value
        
        self.get_logger().info(f"Initialiserer mottaker for FRONT (Port {self.port_front}) og BAK (Port {self.port_back})")
        
        # 2. START PROSESSER
        self.process_front = self.start_gstreamer(self.port_front, "FRONT_KAMERA")
        self.process_back = self.start_gstreamer(self.port_back, "BAK_KAMERA")

    def start_gstreamer(self, port, label):
        """Genererer og starter en optimalisert GStreamer-pipeline for H.265 UDP-mottak"""
        
        # Bruker fpsdisplaysink for å printe navnet på strømmen ("FRONT" / "BAK") i videovinduet
        gst_cmd = (
            f"gst-launch-1.0 udpsrc port={port} "
            f"caps=\"application/x-rtp, media=video, clock-rate=90000, encoding-name=H265, payload=96\" ! "
            f"rtpjitterbuffer latency=100 ! "
            f"rtph265depay ! "
            f"h265parse ! "
            f"avdec_h265 ! "
            f"videoconvert ! "
            f"fpsdisplaysink text-overlay=true video-sink=autovideosink sync=false"
        )
        
        self.get_logger().info(f"Lytter på udp://0.0.0.0:{port}")
        # Starter som en uavhengig prosess
        return subprocess.Popen(gst_cmd, shell=True)

    def stop_streams(self):
        """Rydder opp og dreper videovinduene når ROS-noden avsluttes"""
        self.get_logger().info("Avslutter videostrømmer...")
        if self.process_front:
            self.process_front.terminate()
        if self.process_back:
            self.process_back.terminate()

def main(args=None):
    rclpy.init(args=args)
    node = DualVideoReceiverNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.stop_streams() # Sikrer at vinduene lukkes når du trykker Ctrl+C
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()