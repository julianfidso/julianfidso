from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'guidance_primus'

setup(
    name=package_name,
    version='1.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # Inkluderer launch-filer
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
        # Inkluderer konfigurasjonsfiler (hvis aktuelt senere)
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='System',
    maintainer_email='dev@system.local',
    description='Line-of-Sight (LOS) guidance og waypoint-håndtering for MVP',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'los_guidance_node = guidance_primus.los_guidance_node:main',
            'waypoint_commander = guidance_primus.waypoint_commander:main',
        ],
    },
)