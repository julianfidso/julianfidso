#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point
from geographic_msgs.msg import GeoPoint
from robot_localization.srv import FromLL
import threading
import sys

class WaypointCommander(Node):
    def __init__(self):
        super().__init__('waypoint_commander')
        
        # 1. PUBLISHER (Sender X, Y i meter til LOS-noden)
        self.pub_wp = self.create_publisher(Point, '/waypoint', 10)
        
        # 2. SERVICE CLIENT (Ber navsat_transform om konvertering)
        self.cli_from_ll = self.create_client(FromLL, '/fromLL')

        # Venter på at EKF/navsat_transform skal bli klar
        while not self.cli_from_ll.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Venter på /fromLL tjenesten (er navsat_transform_node startet?)...')

        # 3. Kjører terminal-prompt i en egen tråd
        self.input_thread = threading.Thread(target=self.user_input_loop)
        self.input_thread.daemon = True
        self.input_thread.start()

    def send_conversion_request(self, lat, lon):
        """Kaller på robot_localization for å gjøre om GPS til Meter"""
        req = FromLL.Request()
        req.ll_point = GeoPoint(latitude=lat, longitude=lon, altitude=0.0)
        
        self.get_logger().info(f"Forespør konvertering for: Lat={lat}, Lon={lon}")
        
        # Asynkront tjenestekall
        future = self.cli_from_ll.call_async(req)
        future.add_done_callback(self.conversion_response_callback)

    def conversion_response_callback(self, future):
        """Mottar X, Y (i map/odom frame) og videresender til Autopiloten"""
        try:
            response = future.result()
            target_point = response.map_point # Returnerer en Point (x, y, z)
            
            # Publiserer direkte til LOS-Guidance
            self.pub_wp.publish(target_point)
            
            self.get_logger().info(f">>> SUKSESS: Mål sendt til Autopilot: X={target_point.x:.2f}m, Y={target_point.y:.2f}m")
            print("\nSkriv inn ny 'Latitude, Longitude' for nytt mål (eller 'Ctrl+C' for å avslutte):")
            
        except Exception as e:
            self.get_logger().error(f"Feil under konvertering: {e}")

    def user_input_loop(self):
        """Terminal-grensesnitt (Blokkerer ikke ROS-spin)"""
        print("="*60)
        print(" MVP WAYPOINT COMMANDER ".center(60, "="))
        print("="*60)
        print("Format: Latitude, Longitude (Eks: 58.1465, 7.9956)")
        print("="*60)
        
        while rclpy.ok():
            try:
                user_input = input("\nSkriv mål (Lat, Lon): ")
                
                # Enkel parsing av strengen
                if "," in user_input:
                    parts = user_input.split(",")
                    lat = float(parts[0].strip())
                    lon = float(parts[1].strip())
                    self.send_conversion_request(lat, lon)
                else:
                    print("Feil format! Må bruke komma mellom verdiene.")
            except ValueError:
                print("Ugyldig input. Vennligst bruk tall.")
            except EOFError:
                break # Håndterer Ctrl+D

def main(args=None):
    rclpy.init(args=args)
    node = WaypointCommander()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        sys.stdout.write("\nAvslutter Commander...\n")
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()