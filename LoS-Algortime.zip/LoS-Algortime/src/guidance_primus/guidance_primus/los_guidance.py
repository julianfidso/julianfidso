#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, Point
from nav_msgs.msg import Odometry
import math

class LOSGuidanceNode(Node):
    def __init__(self):
        super().__init__('los_guidance_node')

        # --- 1. PARAMETERE ---
        self.declare_parameter('timer_freq_hz', 10.0)
        self.declare_parameter('waypoint_radius_m', 1.5)
        self.declare_parameter('xte_deadband_m', 0.25)
        self.declare_parameter('yaw_deadband_deg', 3.0)
        
        self.declare_parameter('max_surge_speed', 0.8)
        self.declare_parameter('max_sway_speed', 0.4)
        self.declare_parameter('max_yaw_rate', 0.5)
        
        self.declare_parameter('kp_surge', 0.5)
        self.declare_parameter('kp_sway', 0.8)
        self.declare_parameter('kp_yaw', 1.2)

        # --- 2. TILSTANDSVARIABLER ---
        self.mission_active = False
        
        # Posisjonsdata
        self.curr_x = 0.0
        self.curr_y = 0.0
        self.curr_yaw = 0.0
        
        # Rutedata (Linje fra Start A til Mål B)
        self.start_x = 0.0
        self.start_y = 0.0
        self.target_x = 0.0
        self.target_y = 0.0

        # --- 3. PUBLISHERS & SUBSCRIBERS ---
        self.pub_cmd_vel = self.create_publisher(Twist, '/cmd_vel_nav', 10)
        self.sub_odom = self.create_subscription(Odometry, '/odometry/filtered_global', self.odom_callback, 10)
        self.sub_wp = self.create_subscription(Point, '/waypoint', self.wp_callback, 10)

        # --- 4. TIMER ---
        freq = self.get_parameter('timer_freq_hz').value
        self.timer = self.create_timer(1.0 / freq, self.control_loop)
        
        self.get_logger().info("LOS Guidance Node er klar. Venter på waypoint...")

    # --- HJELPEFUNKSJONER ---
    def euler_from_quaternion(self, q):
        """Konverterer ROS2 Quaternion til Euler Yaw for å unngå tf-avhengigheter."""
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny_cosp, cosy_cosp)

    def normalize_angle(self, angle):
        """Normaliserer vinkel til [-pi, pi]."""
        while angle > math.pi:
            angle -= 2.0 * math.pi
        while angle < -math.pi:
            angle += 2.0 * math.pi
        return angle

    # --- CALLBACKS ---
    def odom_callback(self, msg):
        self.curr_x = msg.pose.pose.position.x
        self.curr_y = msg.pose.pose.position.y
        self.curr_yaw = self.euler_from_quaternion(msg.pose.pose.orientation)

    def wp_callback(self, msg):
        """Utløses én gang når terminalen sender et nytt mål."""
        self.target_x = msg.x
        self.target_y = msg.y
        
        # Definerer 'A' i linjen A->B som der fartøyet var da ordren kom
        self.start_x = self.curr_x
        self.start_y = self.curr_y
        
        self.mission_active = True
        self.get_logger().info(f"Nytt Waypoint mottatt: X={self.target_x:.2f}, Y={self.target_y:.2f}. Starter navigasjon.")

    # --- KONTROLLSLØYPE (Utføres med gitt Hz) ---
    def control_loop(self):
        cmd = Twist()

        if not self.mission_active:
            # Sikrer at vi sender 0-pådrag når vi er i ro
            self.pub_cmd_vel.publish(cmd)
            return

        # 1. Hent parametere
        wp_radius = self.get_parameter('waypoint_radius_m').value
        xte_deadband = self.get_parameter('xte_deadband_m').value
        yaw_deadband = math.radians(self.get_parameter('yaw_deadband_deg').value)
        
        kp_surge = self.get_parameter('kp_surge').value
        kp_sway = self.get_parameter('kp_sway').value
        kp_yaw = self.get_parameter('kp_yaw').value

        # 2. Beregn avstand til mål
        dist_to_target = math.hypot(self.target_x - self.curr_x, self.target_y - self.curr_y)

        # SJEKK: Er vi fremme?
        if dist_to_target <= wp_radius:
            self.mission_active = False
            self.get_logger().info("Waypoint nådd. Stopper fartøy.")
            self.pub_cmd_vel.publish(cmd) # Sender 0-fart
            return

        # 3. YAW REGULERING (Sikt direkte på målet)
        target_yaw = math.atan2(self.target_y - self.curr_y, self.target_x - self.curr_x)
        yaw_error = self.normalize_angle(target_yaw - self.curr_yaw)
        
        if abs(yaw_error) < yaw_deadband:
            yaw_error = 0.0

        # 4. SWAY REGULERING (Kryssavvik / XTE)
        # Vinkel på den planlagte ruten (A -> B)
        path_angle = math.atan2(self.target_y - self.start_y, self.target_x - self.start_x)
        
        # XTE (Ortogonal avstand fra linjen). Positiv = Fartøyet er til venstre for linjen.
        xte = -(self.curr_x - self.start_x) * math.sin(path_angle) + (self.curr_y - self.start_y) * math.cos(path_angle)

        if abs(xte) < xte_deadband:
            xte = 0.0

        # 5. P-REGULATOR (Genererer Twist)
        # Surge: Brems ned proporsjonalt når vi nærmer oss radiusen, ellers gi gass
        raw_surge = kp_surge * dist_to_target
        # Sway: Hvis XTE er positiv (vi er til venstre), må vi kjøre til høyre (negativ sway)
        raw_sway = kp_sway * (-xte)
        # Yaw: Proporsjonal sving mot målet
        raw_yaw = kp_yaw * yaw_error

        # 6. BEGRENSNINGER (Clamping for sikkerhet)
        cmd.linear.x = max(min(raw_surge, self.get_parameter('max_surge_speed').value), 0.0) # Tillater ikke rygging
        cmd.linear.y = max(min(raw_sway, self.get_parameter('max_sway_speed').value), -self.get_parameter('max_sway_speed').value)
        cmd.angular.z = max(min(raw_yaw, self.get_parameter('max_yaw_rate').value), -self.get_parameter('max_yaw_rate').value)

        # 7. PUBLISER
        self.pub_cmd_vel.publish(cmd)

def main(args=None):
    rclpy.init(args=args)
    node = LOSGuidanceNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()