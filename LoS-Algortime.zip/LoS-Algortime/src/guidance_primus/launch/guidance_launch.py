import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    
    # Henter YAML-filen for dødbånd og P-ledd
    config = os.path.join(
        get_package_share_directory('guidance_primus'),
        'config',
        'los_params.yaml'
    )

    los_guidance_node = Node(
        package='guidance_primus',
        executable='los_guidance_node',
        name='los_guidance_node',
        parameters=[config],
        output='screen'
    )

    # MERK: Waypoint Commander startes IKKE her.
    # Terminal-input (stdin) fungerer dårlig i bakgrunnen via launch-filer.

    return LaunchDescription([
        los_guidance_node
    ])